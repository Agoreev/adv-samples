self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "024e8c33f3205b0b0751f4365499d0cd",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "1d93cd115f0ab2de0fc8",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "cf636fbfc9ba849bbc18",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.309a7a62.chunk.css"
  },
  {
    "revision": "1d93cd115f0ab2de0fc8",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.19ccde61.chunk.js"
  },
  {
    "revision": "702e06c21f4db63e7e05a8a0eda9baf1",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.19ccde61.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cf636fbfc9ba849bbc18",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.a40c2ac3.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  },
  {
    "revision": "1926eb64860c5ae61e5a3b9a4bf87f8e",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/media/equalizer.1926eb64.svg"
  }
]);