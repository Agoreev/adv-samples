self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2317b64c5c1c3724404ca0c48dfc0175",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "3a03591ef383c405e7f9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "e702157bff6583d34975",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.652e2b6d.chunk.css"
  },
  {
    "revision": "3a03591ef383c405e7f9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.abdcf6d5.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.abdcf6d5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e702157bff6583d34975",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.79753b47.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  }
]);