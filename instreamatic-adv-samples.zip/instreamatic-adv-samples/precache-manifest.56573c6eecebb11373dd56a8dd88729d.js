self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1bafe3ac2033022c0e54d36247f9826a",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "3a03591ef383c405e7f9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "613945e45276c2007216",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.75df85bf.chunk.css"
  },
  {
    "revision": "3a03591ef383c405e7f9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.abdcf6d5.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.abdcf6d5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "613945e45276c2007216",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.31ec2728.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  }
]);