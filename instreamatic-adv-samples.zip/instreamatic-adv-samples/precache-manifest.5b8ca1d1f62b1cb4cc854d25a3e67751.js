self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4c73a7013249157939b913f57b4f7184",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "f548f036c29843225aae",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "697d59d4c1dcafebf80f",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.1dec43f0.chunk.css"
  },
  {
    "revision": "f548f036c29843225aae",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.d9678988.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.d9678988.chunk.js.LICENSE.txt"
  },
  {
    "revision": "697d59d4c1dcafebf80f",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.3c6c2105.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  }
]);