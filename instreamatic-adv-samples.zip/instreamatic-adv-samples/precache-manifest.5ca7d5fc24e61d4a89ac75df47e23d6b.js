self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "88194ecfd5e8775194107df6ab182df8",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "a424c8a07d26c5af21e9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "4e8d49553083683b24d4",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.3d0bba1e.chunk.css"
  },
  {
    "revision": "a424c8a07d26c5af21e9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.4a671ba4.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.4a671ba4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4e8d49553083683b24d4",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.776c42af.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  }
]);