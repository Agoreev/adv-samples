self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "89b3be708f1aaf9f76023c33a077cc3c",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "a424c8a07d26c5af21e9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "f48d725e345c556a00da",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.64edd3d0.chunk.css"
  },
  {
    "revision": "a424c8a07d26c5af21e9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.4a671ba4.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.4a671ba4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f48d725e345c556a00da",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.350a511d.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  }
]);