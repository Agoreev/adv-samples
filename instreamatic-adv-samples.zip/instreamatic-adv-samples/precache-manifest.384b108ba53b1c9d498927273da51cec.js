self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "74edb5d7e936a17b47f907d52dc273fc",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "82e9a58b1f89f5b26c89",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "5bc4e905c63b75174443",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.ef0703e0.chunk.css"
  },
  {
    "revision": "82e9a58b1f89f5b26c89",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.52a8d74e.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.52a8d74e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5bc4e905c63b75174443",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.41eb43ce.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  }
]);