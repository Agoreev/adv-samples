self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "abb12632ad9844a2402b70ebf1a123bf",
    "url": "/wp-content/mu-plugins/adv-samples/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "a424c8a07d26c5af21e9",
    "url": "/wp-content/mu-plugins/adv-samples/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "9235c422ee8b45359a9b",
    "url": "/wp-content/mu-plugins/adv-samples/instreamatic-adv-samples/static/css/main.772349ae.chunk.css"
  },
  {
    "revision": "a424c8a07d26c5af21e9",
    "url": "/wp-content/mu-plugins/adv-samples/instreamatic-adv-samples/static/js/2.4a671ba4.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/wp-content/mu-plugins/adv-samples/instreamatic-adv-samples/static/js/2.4a671ba4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9235c422ee8b45359a9b",
    "url": "/wp-content/mu-plugins/adv-samples/instreamatic-adv-samples/static/js/main.7919ead1.chunk.js"
  },
  {
    "revision": "81df326be525495792e1",
    "url": "/wp-content/mu-plugins/adv-samples/instreamatic-adv-samples/static/js/runtime-main.9a0568de.js"
  }
]);