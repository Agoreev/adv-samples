self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3c87c9ba6ea1d444e0d29430a77b5e8e",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "3a03591ef383c405e7f9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "b5654ffe7dd2401d9dcd",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.652e2b6d.chunk.css"
  },
  {
    "revision": "3a03591ef383c405e7f9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.abdcf6d5.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.abdcf6d5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b5654ffe7dd2401d9dcd",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.4e6564a5.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  }
]);