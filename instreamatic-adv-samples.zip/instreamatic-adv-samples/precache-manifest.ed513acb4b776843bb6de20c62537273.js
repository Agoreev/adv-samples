self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b2ce86870dc5491df65dc1354bc58d72",
    "url": "/wp-content/plugins/instreamatic/index.html"
  },
  {
    "revision": "3a03591ef383c405e7f9",
    "url": "/wp-content/plugins/instreamatic/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "e718c144e0de4db3b17f",
    "url": "/wp-content/plugins/instreamatic/static/css/main.ee4625e0.chunk.css"
  },
  {
    "revision": "3a03591ef383c405e7f9",
    "url": "/wp-content/plugins/instreamatic/static/js/2.abdcf6d5.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/wp-content/plugins/instreamatic/static/js/2.abdcf6d5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e718c144e0de4db3b17f",
    "url": "/wp-content/plugins/instreamatic/static/js/main.cbf62a14.chunk.js"
  },
  {
    "revision": "d0282683a00cf1d97217",
    "url": "/wp-content/plugins/instreamatic/static/js/runtime-main.02b6d775.js"
  }
]);