self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "86526b609f733ec318fbaa77d2c50721",
    "url": "/wp-content/plugins/instreamatic-adv-samples/index.html"
  },
  {
    "revision": "6186cc43750b0ac8c4e1",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/2.9131a3d6.chunk.css"
  },
  {
    "revision": "db8b143128a7694765a9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/css/main.88e5fe82.chunk.css"
  },
  {
    "revision": "6186cc43750b0ac8c4e1",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.a4b1a2c0.chunk.js"
  },
  {
    "revision": "702e06c21f4db63e7e05a8a0eda9baf1",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/2.a4b1a2c0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "db8b143128a7694765a9",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/main.a10f3f67.chunk.js"
  },
  {
    "revision": "246bc59d81e679416e2d",
    "url": "/wp-content/plugins/instreamatic-adv-samples/static/js/runtime-main.f0232b63.js"
  }
]);